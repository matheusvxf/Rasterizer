#include "DiffuseLight.h"

DiffuseLight::DiffuseLight()
{
}

DiffuseLight::~DiffuseLight()
{
}
