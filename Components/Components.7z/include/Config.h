#pragma once

#include "DataType.h"

#define UTILITY_MACRO TRUE
#define DEBUG TRUE
#define DEBUG_GRAPHICS FALSE
#define PROJECT_2_PRINT TRUE
#define COLOR_BY_DISTANCE TRUE
#define DEFINE_DATA_TYPE FALSE
#define COLUMN_MAJOR FALSE
#define USE_MY_RASTERIZER TRUE