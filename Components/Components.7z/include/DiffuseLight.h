#pragma once
#include "Light.h"

class DiffuseLight :
    public Light
{
public:
    DiffuseLight();
    ~DiffuseLight();
};

